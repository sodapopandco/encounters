# Encounters

A simple colour palette for writing day or night. Maybe it’s a program to take over the world. Maybe it’s a website for a friend. Maybe it’s the Great American Novel. Or maybe it’s just straight up fart jokes. It’s all you, kid!

## Preview

[http://encounters.io](http://encounters.io)

## Editors

* [Atom](http://atom.io)
* [Sublime Text](http://www.sublimetext.com)
* [TextMate](http://macromates.com)

## Palette

A reversible colour palette means that whatever time of day it is, you can work in a familiar environment that’s easy on your eyes and colourful enough to keep things organised.
