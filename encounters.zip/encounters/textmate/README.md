# Installation
## TextMate 1
1. Open both `Encounters (Dark).tmTheme` and `Encounters (Light).tmTheme`.
2. Open TextMate.
3. Select `Preferences > Fonts & Colors` and choose either theme.

## TextMate 2
1. Open the `Encounters.tmbundle` file and in the dialog that opens in TextMate, choose `Install`.
2. Open TextMate.
3. Select `View > Themes` and choose either theme.