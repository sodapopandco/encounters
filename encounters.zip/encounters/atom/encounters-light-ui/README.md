# Encounters (Light) UI

A simple colour palette for writing day or night.
