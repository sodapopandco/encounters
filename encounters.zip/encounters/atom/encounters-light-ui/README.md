# Encounters (Light) UI

A simple colour palette for writing day or night.

![](https://f.cloud.github.com/assets/671378/2265086/c6897dba-9e7b-11e3-945d-551cac610717.png)
