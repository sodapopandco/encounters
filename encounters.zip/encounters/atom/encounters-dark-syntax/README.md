# Encounters (Dark)

A simple colour palette for writing day or night.
