# Installation
1. Copy both `encounters-dark-syntax` and `encounters-light-syntax` folders into the `~/.atom/packages` directory.
2. Select `Atom > Preferences` and select the `Themes` tab.
3. Choose either theme in the `Syntax Theme` dropdown menu.
