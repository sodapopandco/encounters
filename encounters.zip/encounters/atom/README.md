# Installation
1. Copy both `encounters-dark-syntax` and `encounters-light-syntax` folders into the `~/.atom/packages` directory.
2. Select `Atom > Preferences` and select the `Themes` tab.
3. Choose either theme in the `Syntax Theme` dropdown menu.

# UI Installation
1. Copy both `encounters-dark-ui` and `encounters-light-ui` folders into the `~/.atom/packages` directory.
2. Select `Atom > Preferences` and select the `Themes` tab.
3. Choose either theme in the `UI Theme` dropdown menu.
