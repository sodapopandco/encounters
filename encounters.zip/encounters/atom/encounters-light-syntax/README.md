# Encounters (Light)

A simple colour palette for writing day or night.
