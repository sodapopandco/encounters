# Installation
1. Copy the `Encounters` folder inside this folder.
2. Open Sublime Text.
3. Select `Preferences > Browse Packages…`.
4. Paste the folder you copied earlier into the folder that opened when you selected `Preferences > Browse Packages…`.
5. Then, In Sublime Text, select `Preferences > Color Scheme > User > Encounters` and choose either theme.